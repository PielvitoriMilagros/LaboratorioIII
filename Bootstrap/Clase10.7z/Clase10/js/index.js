let selPaises;
let selCiudades;

window.addEventListener('load', function(){
    selPaises = document.getElementById('selPaises');
    selCiudades = document.getElementById('selCiudades');
    
    cargarSelect(selPaises, obtenerPaises(datos));
    cargarSelect(selCiudades, obtenerCiudades(datos, selPaises.value));
    selPaises.addEventListener('change', (e)=>{
        //e.ciudades.option.lenght=0;
        cargarSelect(selCiudades, obtenerCiudades(datos, e.target.value));
    });
});

function obtenerPaises(arr){
    //map->recibe: valor, indice, array
    // let paises = arr.map(function(element){
    //     return element.pais;
    // });
    return paises = arr.map(element=>element.pais)
    .unique()
    .sort();

}
function obtenerCiudades(arr, pais){
    //let ciudades = arr.filter(function(element){ return element.pais === pais; })
    let ciudades = arr.filter(element=>element.pais === pais)
    .map(element=>element.ciudad)
    .unique()
    .sort();
    return ciudades;
}

function cargarSelect(sel, arr){
    //sel.option.lenght=0;
    //console.log(sel.options.lenght);
    //ejemplo de foreach

    limpiarSelect(sel);
    arr.forEach(element=>{
        let option=document.createElement('option');
        option.setAttribute('value', element);
        //asi:
        //option.textContent
        //o mejor asì:
        //(se pone entre parentesis el nombre)
        let text = document.createTextNode(element);
        option.appendChild(text);
        sel.appendChild(option);

    });
}

Array.prototype.unique=function(){
    return [...new Set(this)];
}

function limpiarSelect(sel)
{
    while(sel.hasChildNodes()){
        //sel.remove(sel.firstChildElementChild);
        sel.remove(sel.firstChildElementChild);
    }
}