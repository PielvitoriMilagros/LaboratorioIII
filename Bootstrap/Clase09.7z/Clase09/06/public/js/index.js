$(function(){
    $('#btnCargar').click(function(){
        var impresion_consola=function(){
            console.log(datos);
        }
        cargarDatos(impresion_consola);
    })
})