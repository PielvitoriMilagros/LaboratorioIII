$(function(){

    //tarda 4 segundos en esconderse:
    //$("p:last").hide(4000);

    //tarda 4 segundos en esconderse y 4 segundos en aparecer:
    // $("p:last").hide(4000, function(){
    //     $("p:last").show(4000);
    // });

    //si esta oculto lo muestra y si se muestra se oculta:
     $("#btnEnviar").toggle(4000, function(){
         $("#btnEnviar").toggle(4000);
     });
    $("#btnEnviar").click(function(){
        $("#btnEnviar").animate({
            height: '+=50px',
            wigth: '+=50px'
        }, 1000).animate({
            height: '-=50px',
            wigth: '-=50px'
        }, 1000)
    });
	//otras animaciones
	/*
		slideDown(4000);
		slideUp(4000);
		slideToggle(4000);
		fadeIn(4000);
		fadeOut(4000);
		fadeToggle(4000);
	*/
})